<?php
session_start();
$User= "user";
$Pass="123";
if(isset($_POST['username']) and isset($_POST['password'])) {
  if($_POST['username']==$User and $_POST['password']==$Pass) {
    $_SESSION['status_login']=1;
    $_SESSION['username']=$_POST['username'];
    $_SESSION['password']=$_POST['password'];
    header('location:FileManager_M0517046.php');
  }
  else {
    echo "Login SALAH..!!";
    die("Silakan login kembali <a href='login.php'>Disini</a>");
  }
}
else {
  echo "Data tidak lengkap..!!";
} 
?>