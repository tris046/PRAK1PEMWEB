<?php
	echo"<form action ='validate.php' method='POST'>
	</br></br>
	<h2 align=\"center\">Login User</h2></br>
	<p align=\"center\">Username :
	<input type='text' name='username' class=\'textfield\'id=\'login\'/></p>
	<p align=\"center\">Password :
	<input type='password' name='password' class=\'textfield\' id=\'password\'/></p>
	<p align=\"center\"><button class=\'button\' type=\"submit\" class=\"positive\" name=\"login\" width=\"60\" height=\"30\">
    <img src=\"img/lo.png\" alt=\"Login\"/ width=\"60\" height=\"30\">
    </button></p>
	</form>";
?>
